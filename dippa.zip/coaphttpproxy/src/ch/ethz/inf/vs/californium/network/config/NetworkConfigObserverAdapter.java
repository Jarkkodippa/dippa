package ch.ethz.inf.vs.californium.network.config;

public class NetworkConfigObserverAdapter implements NetworkConfigObserver {

	@Override
	public void changed(String key, Object value) {
		// do nothing
	}

	@Override
	public void changed(String key, String value) {
		// do nothing
	}

	@Override
	public void changed(String key, int value) {
		// do nothing
	}

	@Override
	public void changed(String key, long value) {
		// do nothing
	}

	@Override
	public void changed(String key, float value) {
		// do nothing
	}

	@Override
	public void changed(String key, double value) {
		// do nothing
	}

	@Override
	public void changed(String key, boolean value) {
		// do nothing
	}
	
}
